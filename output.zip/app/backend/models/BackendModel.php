<?php
/**
 * Created by PhpStorm.
 * Author: 芸众商城 www.yunzshop.com
 * Date: 02/03/2017
 * Time: 15:41
 */

namespace app\backend\models;


use app\common\models\BaseModel;

class BackendModel extends BaseModel
{
    
}
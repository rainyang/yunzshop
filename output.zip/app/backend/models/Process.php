<?php
/**
 * Created by PhpStorm.
 * User: shenyang
 * Date: 2018/6/18
 * Time: 下午9:02
 */

namespace app\backend\models;


class Process extends \app\common\models\Process
{

}
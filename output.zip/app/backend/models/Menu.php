<?php
/**
 * Created by PhpStorm.
 * Author: 芸众商城 www.yunzshop.com
 * Date: 09/03/2017
 * Time: 10:52
 */

namespace app\backend\models;


class Menu extends \app\common\models\Menu
{

}
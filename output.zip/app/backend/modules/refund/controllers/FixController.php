<?php
namespace app\backend\modules\refund\controllers;

use app\backend\modules\refund\models\RefundApply;
use app\common\components\BaseController;

/**
 * Created by PhpStorm.
 * Author: 芸众商城 www.yunzshop.com
 * Date: 2017/4/21
 * Time: 下午2:43
 */
class FixController extends BaseController
{
//    public function backReject(\Request $request){
//        $refundApply = RefundApply::find($request->query('refund_id'));
//        $refundApply->status = 0;
//        $refundApply->reject_reason = '';
//        $refundApply->save();
//        echo 'ok';
//    }
}
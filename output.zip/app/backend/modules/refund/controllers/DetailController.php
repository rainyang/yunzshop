<?php

/**
 * 退款申请详情
 * Created by PhpStorm.
 * Author: 芸众商城 www.yunzshop.com
 * Date: 2017/4/13
 * Time: 下午3:04
 */
class DetailController
{

}
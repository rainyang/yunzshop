<?php
namespace app\backend\modules\goods\services;
/**
 * Created by PhpStorm.
 * Author: 芸众商城 www.yunzshop.com
 * Date: 2017/2/27
 * Time: 上午9:18
 */
class BrandService
{

}
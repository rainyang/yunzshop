<?php
/**
 * Created by PhpStorm.
 * Author: 芸众商城 www.yunzshop.com
 * Date: 2017/3/4
 * Time: 上午11:24
 */

namespace app\backend\modules\goods\models;


class Area  extends \app\common\models\Area
{
    static protected $needLog = true;

}
<?php
/**
 * Created by PhpStorm.
 * Author: 芸众商城 www.yunzshop.com
 * Date: 2017/2/22
 * Time: 下午18:16
 */
namespace app\backend\modules\goods\models;


class GoodsSpecItem extends \app\common\models\GoodsSpecItem
{
    static protected $needLog = true;

}
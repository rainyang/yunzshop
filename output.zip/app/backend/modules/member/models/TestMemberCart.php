<?php
/**
 * Created by PhpStorm.
 * Author: 芸众商城 www.yunzshop.com
 * Date: 22/02/2017
 * Time: 13:42
 */

namespace app\backend\modules\member\models;


class TestMemberCart extends \app\common\models\TestMemberCart
{

}

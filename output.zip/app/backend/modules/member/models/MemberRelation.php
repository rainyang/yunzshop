<?php
/**
 * Created by PhpStorm.
 * Author: 芸众商城 www.yunzshop.com
 * Date: 17/3/8
 * Time: 上午9:32
 */

namespace app\backend\modules\member\models;



class MemberRelation extends \app\common\models\MemberRelation
{

}

<?php
/**
 * Created by PhpStorm.
 *
 * User: king/QQ：995265288
 * Date: 2018/6/15 上午10:04
 * Email: livsyitian@163.com
 */

namespace app\backend\modules\withdraw\models;


class Withdraw extends \app\common\models\Withdraw
{

}

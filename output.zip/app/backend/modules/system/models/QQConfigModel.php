<?php
/**
 * Created by PhpStorm.
 * Author: 芸众商城 www.yunzshop.com
 * Date: 17/2/23
 * Time: 上午10:54
 */

/**
 * QQ平台配置表
 */
namespace app\backend\modules\system\modules;

use Illuminate\Database\Eloquent\Model;

class QQConfigModel extends Model
{
    public $table = 'yz_config';
}
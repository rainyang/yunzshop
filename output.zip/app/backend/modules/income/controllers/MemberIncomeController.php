<?php
/**
 * Created by PhpStorm.
 *
 * User: king/QQ：995265288
 * Date: 2018/5/15 下午2:20
 * Email: livsyitian@163.com
 */

namespace app\backend\modules\income\controllers;


use app\common\components\BaseController;

class MemberIncomeController extends BaseController
{
    public function index()
    {
        //todo 功能待开发
    }

}

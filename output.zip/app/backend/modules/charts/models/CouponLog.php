<?php
/**
 * Created by PhpStorm.
 * User: BC
 * Date: 2018/10/14
 * Time: 22:08
 */

namespace app\backend\modules\charts\models;


use app\common\models\BaseModel;
use app\common\models\MemberCoupon;

class CouponLog extends BaseModel
{
    public $table = 'yz_member_coupon';
}
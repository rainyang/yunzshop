<?php
/**
 * Created by PhpStorm.
 * Author: 芸众商城 www.yunzshop.com
 * Date: 2017/3/9
 * Time: 下午1:53
 */

namespace app\common\events\dispatch;

use app\common\events\order\PreGenerateOrderEvent;

class OrderDispatchWasCalculated extends PreGenerateOrderEvent
{

}
<?php
/**
 * Created by PhpStorm.
 * Author: 芸众商城 www.yunzshop.com
 * Date: 2017/3/20
 * Time: 下午8:11
 */

namespace app\common\events\order;


class AfterOrderChangedPriceEvent extends CreatedOrderStatusChangedEvent
{

}
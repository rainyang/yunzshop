<?php
/**
 * 订单收货后事件
 * Created by PhpStorm.
 * Author: 芸众商城 www.yunzshop.com
 * Date: 2017/3/3
 * Time: 上午11:44
 */

namespace app\common\events\order;

class AfterOrderReceivedImmediatelyEvent extends CreatedOrderStatusChangedEvent
{

}
<?php
/**
 * Created by PhpStorm.
 * User: shenyang
 * Date: 2017/5/23
 * Time: 下午4:15
 */

namespace app\common\events\order;


class AfterOrderRefundedEvent extends CreatedOrderEvent
{

}
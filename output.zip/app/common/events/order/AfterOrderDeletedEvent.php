<?php
/**
 * Created by PhpStorm.
 * Author: 芸众商城 www.yunzshop.com
 * Date: 2017/3/17
 * Time: 下午9:12
 */

namespace app\common\events\order;


class AfterOrderDeletedEvent extends CreatedOrderStatusChangedEvent
{

}
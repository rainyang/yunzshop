<?php
/**
 * Created by PhpStorm.
 * Author: 芸众商城 www.yunzshop.com
 * Date: 2017/5/21
 * Time: 下午3:26
 */

namespace app\common\events\member;


class MemberGoldEvent extends GetMemberGoldEvent
{

}
<?php

/**
 * Author: 芸众商城 www.yunzshop.com
 * Date: 2017/7/25
 * Time: 下午2:56
 */

namespace app\common\events\message;

class SendMessageEvent extends MessageEvent
{

}
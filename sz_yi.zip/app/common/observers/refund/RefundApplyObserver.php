<?php

/**
 * Created by PhpStorm.
 * User: yangyang
 * Date: 2017/3/29
 * Time: 下午9:57
 */
namespace app\common\observers\refund;
use app\common\observers\BaseObserver;
use Illuminate\Database\Eloquent\Model;

class RefundApplyObserver extends BaseObserver
{


}
<?php
/**
 * Created by PhpStorm.
 * User: dingran
 * Date: 2017/3/20
 * Time: 上午10:43
 */

namespace app\common\models;


class PayWithdrawOrder
{
    public $table = 'yz_withdraw_order';
}
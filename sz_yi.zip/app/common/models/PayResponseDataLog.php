<?php
/**
 * Created by PhpStorm.
 * User: dingran
 * Date: 2017/3/20
 * Time: 上午10:45
 */

namespace app\common\models;


class PayResponseDataLog
{
    public $table = 'yz_pay_response_data';
}
<?php
/**
 * Created by PhpStorm.
 * User: jan
 * Date: 22/02/2017
 * Time: 13:41
 */

namespace app\common\models;


use Illuminate\Database\Eloquent\Model;

class TestMemberCart extends  Model
{
    public $table = 'member_cart';


}
<?php
/**
 * Created by PhpStorm.
 * User: yanglei
 * Date: 2017/2/28
 * Time: 上午11:32
 */

namespace app\common\models;


class PayType extends BaseModel
{
    public $table = 'yz_pay_type';


}
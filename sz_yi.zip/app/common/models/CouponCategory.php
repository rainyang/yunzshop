<?php

namespace app\common\models;

use Illuminate\Database\Eloquent\Model;

class CouponCategory extends BaseModel
{
    //
}

<?php
/**
 * Created by PhpStorm.
 * User: shenyang
 * Date: 2017/3/14
 * Time: 上午11:01
 */

namespace app\common\models;


class OrderAddress extends BaseModel
{
    public $table = 'yz_order_address';
    protected $fillable = [];
    protected $guarded = ['id'];

}
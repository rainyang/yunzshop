<?php
/**
 * Created by PhpStorm.
 * User: yangyang
 * Date: 2017/3/9
 * Time: 上午11:48
 */

namespace app\common\models\order;


use app\common\models\BaseModel;

class Pay extends BaseModel
{
    public $table = 'yz_order_pay';
}
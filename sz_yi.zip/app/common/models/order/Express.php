<?php
/**
 * Created by PhpStorm.
 * User: yangyang
 * Date: 2017/3/7
 * Time: 下午2:01
 */

namespace app\common\models\order;



use app\common\models\BaseModel;

class Express extends BaseModel
{
    public $table = 'yz_order_express';
}
<?php
/**
 * Created by PhpStorm.
 * User: Rui
 * Date: 2017/3/1
 * Time: 09:41
 */

namespace app\common\models;


class GoodsSpec extends \app\common\models\BaseModel
{
    public $table = 'yz_goods_spec';
    
    public $guarded = [];

    //public $timestamps = false;

    
}
<?php
/**
 * Created by PhpStorm.
 * User: shenyang
 * Date: 2017/3/23
 * Time: 上午10:49
 */

namespace app\common\order\models;

use app\common\models\BaseModel;

class Express extends BaseModel
{
    public $table = 'yz_order_refund_express';

}
<?php
/**
 * Created by PhpStorm.
 * User: Rui
 * Date: 2017/2/23
 * Time: 08:43
 */

namespace app\common\models;


class GoodsParam extends \app\common\models\BaseModel
{
    public $table = 'yz_goods_param';

    public $guarded = [];

    //public $timestamps = false;
}
<?php
namespace app\common\models\coupon;
use app\common\models\BaseModel;

/**
 * Created by PhpStorm.
 * User: shenyang
 * Date: 2017/4/12
 * Time: 下午6:04
 */
class GoodsMemberCoupon extends BaseModel
{

}
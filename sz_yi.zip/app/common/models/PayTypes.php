<?php
/**
 * Created by PhpStorm.
 * User: dingran
 * Date: 2017/3/20
 * Time: 上午10:48
 */

namespace app\common\models;


class PayTypes
{
    public $table = 'yz_pay_types';
}
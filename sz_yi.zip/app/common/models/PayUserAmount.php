<?php
/**
 * Created by PhpStorm.
 * User: dingran
 * Date: 2017/3/20
 * Time: 上午10:50
 */

namespace app\common\models;


class PayUserAmount
{
    public $table = 'yz_user_amount';
}
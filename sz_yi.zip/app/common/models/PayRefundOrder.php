<?php
/**
 * Created by PhpStorm.
 * User: dingran
 * Date: 2017/3/20
 * Time: 上午10:44
 */

namespace app\common\models;


class PayRefundOrder
{
    public $table = 'yz_refund_order';
}
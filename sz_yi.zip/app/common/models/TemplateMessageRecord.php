<?php
/**
 * Created by PhpStorm.
 * User: jan
 * Date: 17/03/2017
 * Time: 16:36
 */

namespace app\common\models;


class TemplateMessageRecord extends BaseModel
{
    public $table = 'yz_template_message_record';
}
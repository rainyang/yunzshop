<?php
/**
 * 订单取消后事件
 * Created by PhpStorm.
 * User: shenyang
 * Date: 2017/3/3
 * Time: 上午11:44
 */

namespace app\common\events\order;

class BeforeOrderPayEvent extends BeforeCreatedOrderStatusChangeEvent
{

}
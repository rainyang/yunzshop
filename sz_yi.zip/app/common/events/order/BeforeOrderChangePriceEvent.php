<?php
/**
 * Created by PhpStorm.
 * User: shenyang
 * Date: 2017/3/20
 * Time: 下午8:11
 */

namespace app\common\events\order;


class BeforeOrderChangePriceEvent extends BeforeCreatedOrderStatusChangeEvent
{

}
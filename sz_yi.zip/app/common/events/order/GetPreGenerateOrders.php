<?php
/**
 * Created by PhpStorm.
 * User: shenyang
 * Date: 2017/4/10
 * Time: 上午11:14
 */

namespace app\common\events\order;


class getPreGenerateOrders
{

}
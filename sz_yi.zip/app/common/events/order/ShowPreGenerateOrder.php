<?php
/**
 * Created by PhpStorm.
 * User: shenyang
 * Date: 2017/4/7
 * Time: 下午9:18
 */

namespace app\common\events\order;

class ShowPreGenerateOrder extends CreatingOrder
{

}
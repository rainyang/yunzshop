<?php
/**
 * Created by PhpStorm.
 * User: shenyang
 * Date: 2017/3/17
 * Time: 下午9:12
 */

namespace app\common\events\order;


class AfterOrderDeletedEvent extends CreatedOrderStatusChangedEvent
{

}
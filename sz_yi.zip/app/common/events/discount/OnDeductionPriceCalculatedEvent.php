<?php
/**
 * Created by PhpStorm.
 * User: shenyang
 * Date: 2017/3/25
 * Time: 下午1:44
 */

namespace app\common\events\discount;


use app\common\events\order\PreGenerateOrderEvent;

class OnDeductionPriceCalculatedEvent extends PreGenerateOrderEvent
{

}
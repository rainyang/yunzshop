<?php
/**
 * Created by PhpStorm.
 * User: jan
 * Date: 23/02/2017
 * Time: 19:09
 */

namespace app\common\requests;


use Illuminate\Foundation\Http\FormRequest;

class Request extends FormRequest
{

}
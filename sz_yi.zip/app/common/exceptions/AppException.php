<?php
/**
 * Created by PhpStorm.
 * User: shenyang
 * Date: 2017/3/28
 * Time: 下午4:36
 */

namespace app\common\exceptions;
use Exception;


class AppException extends Exception
{

}
<?php
namespace  app\backend\controllers;
/**
 * Created by PhpStorm.
 * User: jan
 * Date: 21/02/2017
 * Time: 16:46
 */
class CacheController
{
    public function index()
    {
        echo __CLASS__;
    }

}
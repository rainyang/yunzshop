<?php
/**
 * Created by PhpStorm.
 * User: jan
 * Date: 22/02/2017
 * Time: 13:42
 */

namespace app\backend\modules\member\models;


class TestMemberCart extends \app\common\models\TestMemberCart
{

}

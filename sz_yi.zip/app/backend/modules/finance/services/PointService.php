<?php
/**
 * Created by PhpStorm.
 * User: yangyang
 * Date: 2017/4/11
 * Time: 上午10:39
 */

namespace app\backend\modules\finance\services;


class PointService extends \app\common\services\finance\PointService
{

}
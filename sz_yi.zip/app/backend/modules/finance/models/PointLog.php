<?php
/**
 * Created by PhpStorm.
 * User: yangyang
 * Date: 2017/4/10
 * Time: 下午5:47
 */

namespace app\backend\modules\finance\models;


class PointLog extends \app\common\models\finance\PointLog
{

}
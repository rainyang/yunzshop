<?php
/**
 * Created by PhpStorm.
 * User: yanglei
 * Date: 2017/4/5
 * Time: 下午7:36
 */

namespace app\backend\modules\finance\models;


class IncomeOrder extends \app\common\models\finance\IncomeOrder
{

    
}
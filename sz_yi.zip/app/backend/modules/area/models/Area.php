<?php
/**
 * Created by PhpStorm.
 * User: luckystar_D
 * Date: 2017/3/4
 * Time: 上午11:24
 */

namespace app\backend\modules\area\models;


class Area  extends \app\common\models\Area
{
    
}
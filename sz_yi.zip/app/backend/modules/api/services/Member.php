<?php

namespace app\backend\modules\api\services;

/**
 * Created by PhpStorm.
 * User: jan
 * Date: 21/02/2017
 * Time: 17:05
 */
class Member
{
    public static function tree()
    {

    }
}
应用总目录
    backend   后台
        controllers 控制器
            CacheController.php
        models      模型
        services    服务
        views       视图
        modules     模块
            api
                controllers
                models
                services
                views
                modules
                    v1
                        controllers
                            TestController.php
                        models
                        services
                    v2
            order
                controllers
                    OrderController.php
                models
                services
                views

    modules    模块
        goods
            controllers
            models
            services
            views
            modules

    common
        models
            Member.php
        services
        helpers
        extensions
    frontend    前端(同1)
    plugins    插件
        commission
            controllers
            models
            services
            views
            modules
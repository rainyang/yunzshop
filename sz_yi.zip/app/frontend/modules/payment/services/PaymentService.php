<?php

/**
 * Created by PhpStorm.
 * User: shenyang
 * Date: 2017/3/27
 * Time: 下午2:13
 */
namespace app\frontend\modules\payment\services;

class PaymentService
{

}
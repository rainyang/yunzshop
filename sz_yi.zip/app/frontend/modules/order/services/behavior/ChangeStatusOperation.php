<?php
/**
 * Created by PhpStorm.
 * User: shenyang
 * Date: 2017/3/20
 * Time: 下午8:16
 */

namespace app\frontend\modules\order\services\behavior;


abstract class ChangeStatusOperation extends OrderOperation
{
    /**
     * @var改变后状态
     */
    protected $status_after_changed;
    /**
     * 更新订单表
     * @return bool
     */
    protected function _updateTable(){
        $this->_DbOrderModel->status = $this->status_after_changed;
        if(isset($this->time_field)){
            $time_fields = $this->time_field;
            $this->_DbOrderModel->$time_fields = time();
        }
        return $this->_DbOrderModel->save();
    }

    /**
     * 执行订单操作
     * @return mixed
     */
    public function execute()
    {
        $result = $this->_updateTable();
        $this->_fireEvent();
        return $result;
    }
}
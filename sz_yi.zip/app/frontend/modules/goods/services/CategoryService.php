<?php
/**
 * Created by PhpStorm.
 * User: yanglei
 * Date: 2017/3/3
 * Time: 下午2:35
 */

namespace app\frontend\modules\goods\services;


class CategoryService
{

}
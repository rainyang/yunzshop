<?php

/**
 * Created by PhpStorm.
 * User: shenyang
 * Date: 2017/4/12
 * Time: 下午9:53
 */
class RefundApplyList 
{

}
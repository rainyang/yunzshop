<?php
/**
 * Created by PhpStorm.
 * User: jan
 * Date: 21/02/2017
 * Time: 11:45
 */

return [
    'modules'=>[
        'order',
        'dispatch',
        'refund',
    ]
];
<?php
namespace  app\frontend\controllers;
use app\common\components\BaseController;


class TestCacheController extends BaseController
{
    public function index()
    {
        echo " ";
    }

}
<?php

define('IN_IA', true);

include_once __DIR__ . '/app/laravel.php';

include_once __DIR__ . '/app/yunshop.php';
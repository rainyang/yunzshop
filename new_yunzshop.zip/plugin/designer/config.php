<?php
//芸众商城 QQ:913768135
if (!defined('IN_IA')) {
    exit('Access Denied');
}
return array(
    'version' => '1.0',
    'id' => 'designer',
    'name' => '店铺装修'
);
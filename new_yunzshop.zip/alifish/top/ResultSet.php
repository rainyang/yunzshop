<?php
/**
 * 返回的默认类
 * 
 * @author auto create
 * @since 1.0, 2015-01-20
 */
class ResultSet
{
	
	/** 
	 * 返回的错误码
	 **/
	public $code;
	
	/** 
	 * 返回的错误信息
	 **/
	public $msg;
	
}
